Used by Dart code that accesses APIs defined by the
[API Discovery Service](https://developers.google.com/discovery/v1/reference/apis).
This package is not intended to be consumed directly.

## Features and bugs

Please file feature requests and bugs at the
[issue tracker](https://github.com/google/googleapis.dart/issues).
