The code in this directory is a stripped down, and modified version of `package:platform_detect`.

You can find the original file in Workiva's repository, here:

* https://github.com/Workiva/platform_detect/blob/77d160f1c3be4e20dc085a094209e8cab4aec135/lib/src/browser.dart
