[![pub package](https://img.shields.io/pub/v/dds_service_extensions.svg)](https://pub.dev/packages/dds_service_extensions)
[![package publisher](https://img.shields.io/pub/publisher/dds_service_extensions.svg)](https://pub.dev/packages/dds_service_extensions/publisher)

A package used to expand the `package:vm_service` interface with support for RPCs added in the [Dart Developer Service (DDS) protocol][dds-protocol].

[dds-protocol]: https://github.com/dart-lang/sdk/blob/main/pkg/dds/dds_protocol.md
