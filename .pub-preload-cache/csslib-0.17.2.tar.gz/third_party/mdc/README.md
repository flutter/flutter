This folder contains sample css files from the open-source project
https://github.com/material-components/material-components-web.

The generated .css files were retrieved from:
https://unpkg.com/browse/material-components-web@12.0.0/dist/

This code was included under the terms in the `LICENSE` file.