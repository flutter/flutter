# google_fonts_sample_app

This example application demonstrates how to use [<kbd>google_fonts</kbd>](https://pub.dev/packages/google_fonts) within a simple Flutter app.
