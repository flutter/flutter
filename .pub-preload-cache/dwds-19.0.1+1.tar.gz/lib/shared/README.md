# Shared directory

The files in this directory are shared between DWDS and external packages (e.g.,
the Dart Debug Extension).
