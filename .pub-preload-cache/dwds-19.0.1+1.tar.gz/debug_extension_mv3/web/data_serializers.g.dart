// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'data_serializers.dart';

// **************************************************************************
// BuiltValueGenerator
// **************************************************************************

Serializers _$serializers = (new Serializers().toBuilder()
      ..add(BatchedEvents.serializer)
      ..add(ConnectFailure.serializer)
      ..add(DebugInfo.serializer)
      ..add(DebugStateChange.serializer)
      ..add(DevToolsOpener.serializer)
      ..add(DevToolsRequest.serializer)
      ..add(DevToolsUrl.serializer)
      ..add(ExtensionEvent.serializer)
      ..add(ExtensionRequest.serializer)
      ..add(ExtensionResponse.serializer)
      ..addBuilderFactory(
          const FullType(BuiltList, const [const FullType(ExtensionEvent)]),
          () => new ListBuilder<ExtensionEvent>()))
    .build();

// ignore_for_file: deprecated_member_use_from_same_package,type=lint
