This folder contains a sample css file from the open-source project
https://github.com/getbase/base.

This code was included under the
[MIT Open Source](https://opensource.org/licenses/MIT) license.