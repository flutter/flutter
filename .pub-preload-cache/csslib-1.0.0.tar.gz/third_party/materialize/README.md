This folder contains sample css files from the open-source project
https://github.com/Dogfalo/materialize.

This code was included under the terms in the `LICENSE` file.