This folder contains resources from third parties.
See each subfolder for details.
