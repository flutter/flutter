/// Predicate function of type [T].
typedef Predicate<T> = bool Function(T value);
