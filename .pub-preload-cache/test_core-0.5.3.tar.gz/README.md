[![pub package](https://img.shields.io/pub/v/test_core.svg)](https://pub.dev/packages/test_core)
[![package publisher](https://img.shields.io/pub/publisher/test_core.svg)](https://pub.dev/packages/test_core/publisher)

A minimal package for writing and running tests as well as extensions for
implementing a custom test runner.

If you're interested in testing Dart code, you likely want to use
[package:test](https://pub.dev/packages/test).

At this time this package is not intended to be used publicly. The API is not
yet stable.
