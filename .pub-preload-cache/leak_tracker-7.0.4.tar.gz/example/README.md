Minimal Dart application with leak tracker enabled.
