# autosnapshotting

Example of autosnapshotting usage.
