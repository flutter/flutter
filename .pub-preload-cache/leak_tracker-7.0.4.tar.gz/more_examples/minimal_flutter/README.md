Minimal Flutter application with leak tracker enabled.
