Libraries, that depend on package:test and other g3 test-only code
should be in this folder so that
they can be built separately in g3 with the flag testonly.
