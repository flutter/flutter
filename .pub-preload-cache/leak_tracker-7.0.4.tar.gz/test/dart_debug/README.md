Bots run tests in this folder in debug mode.
To run them locally:

```
dart test --debug test/dart_debug
```
