See the [Chart.js Dart API](https://github.com/google/chartjs.dart/) for a usage example.
