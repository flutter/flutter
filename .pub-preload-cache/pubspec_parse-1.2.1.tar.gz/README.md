[![Build Status](https://github.com/dart-lang/pubspec_parse/workflows/Dart%20CI/badge.svg)](https://github.com/dart-lang/pubspec_parse/actions?query=workflow%3A"Dart+CI"+branch%3Amaster)
[![pub package](https://img.shields.io/pub/v/pubspec_parse.svg)](https://pub.dev/packages/pubspec_parse)

Supports parsing `pubspec.yaml` files with robust error reporting and support
for most of the documented features.

Read more about the [pubspec format](https://dart.dev/tools/pub/pubspec).
