## 0.4.0+1

* Add `implements` to pubspec.

## 0.4.0

* Migrate to null-safety
* Run tests using flutter driver

## 0.3.1+4

* Remove unused `test` dependency.

## 0.3.1+3

* Fix homepage in `pubspec.yaml`.

## 0.3.1+2

* Update package:e2e to use package:integration_test

## 0.3.1+1

* Update package:e2e reference to use the local version in the flutter/plugins
  repository.

## 0.3.1

* Use NetworkInformation API from dart:html, instead of the JS-interop version.

## 0.3.0

* Rename from "experimental_connectivity_web" to "connectivity_for_web", and move to flutter/plugins master.

## 0.2.0

* Add fallback on dart:html for browsers where NetworkInformationAPI is not supported.

## 0.1.0

* Initial release.
