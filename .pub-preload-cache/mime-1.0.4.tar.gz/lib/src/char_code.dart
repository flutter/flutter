// Copyright (c) 2014, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

const int ht = 9;
const int lf = 10;
const int cr = 13;
const int sp = 32;
const int dash = 45;
const int colon = 58;
const int upperA = 65;
const int upperZ = 90;
const int lowerA = 97;
