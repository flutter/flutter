`host.dart` is the source for `lib/src/runner/browser/static/host.dart.js`.

To updated it, run:

```console
dart compile js tool/host.dart -o lib/src/runner/browser/static/host.dart.js
```
