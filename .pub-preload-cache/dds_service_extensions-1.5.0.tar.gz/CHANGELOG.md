## 1.5.0
- Added `DdsExtension.postEvent`.

## 1.4.0

- Added `DdsExtension.getPerfettoVMTimelineWithCpuSamples`.

## 1.3.3

- Updated `vm_service` version to ^11.0.0.

## 1.3.2

- Updated `vm_service` version to ^10.0.0.

## 1.3.1

- Updated `vm_service` version to 9.0.0.

## 1.3.0

- Moved `package:dds/vm_service_extensions.dart` into a standalone package.
