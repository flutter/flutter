`package:devtools_shared` is developed as part of the broader
[DevTools project](https://github.com/flutter/devtools). The `devtools_shared`
version is updated in lockstep with the other
[DevTools packages](https://github.com/flutter/devtools/tree/master/packages). To
see changes and commits for `package:devtools_shared`, please view the git log
[here](https://github.com/flutter/devtools/commits/master/packages/devtools_shared).
