# Example of using `CommandRunner`

This example uses `CommandRunner` to create a tool for drawing ascii art shapes.

`dart run draw.dart circle --radius=10`
