# Example of using `ArgParser`

`dart run example.dart`
