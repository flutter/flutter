import '../../sync_core.dart' as sync_core;
import 'web_driver.dart';

/// Returns a [sync_core.WebDriver] with the same URI + session ID.
sync_core.WebDriver createSyncWebDriver(WebDriver driver) =>
    throw 'Not implemented';
