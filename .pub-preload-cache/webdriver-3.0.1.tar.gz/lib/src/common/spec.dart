// ignore_for_file: constant_identifier_names

/// Defines the WebDriver spec to use. Auto = try to infer the spec based on
/// the response during session creation.
enum WebDriverSpec { Auto, JsonWire, W3c }
