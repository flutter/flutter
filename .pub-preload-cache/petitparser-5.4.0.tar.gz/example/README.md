PetitParser Examples
====================

For more elaborate examples see the official [example repository](https://github.com/petitparser/dart-petitparser-examples) or the [demo page](https://petitparser.github.io/).
 
This directory contains the command-line calculator that is described in the introductory tutorial:
 
    dart example/calc.dart "1 + 2 * 3"
