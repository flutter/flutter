This is a package of classes that are generated from the [DAP specifications](https://microsoft.github.io/debug-adapter-protocol/specification) along with their generating code.

More information on Dart support for DAP is available [here](https://github.com/dart-lang/sdk/blob/main/pkg/dds/tool/dap/README.md).