## 2.0.1

* Update platform_plugin_interface version requirement.

## 2.0.0

* Migrate to null safety.
* Make `baseOS`, `previewSdkInt`, and `securityPatch` nullable types.
* Remove default values for non-nullable types.

## 1.0.2

- Update Flutter SDK constraint.

## 1.0.1

- Documentation typo fixed.

## 1.0.0

- Initial open-source release.
