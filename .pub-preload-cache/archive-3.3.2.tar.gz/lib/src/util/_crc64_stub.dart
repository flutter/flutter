int getCrc64_(List<int> array, [int crc = 0]) {
  throw UnsupportedError('Crc64 requires html or io.');
}

bool isCrc64Supported_() {
  return false;
}
