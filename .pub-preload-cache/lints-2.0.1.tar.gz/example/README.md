An example project that uses Dart recommended lints.
