# flutter\_template\_images

Images used by the `flutter_tools` templates.

This project is an internal dependency of the `flutter` tool, and is
not intended to be used directly. It contains images files used in
`flutter create` templates, to avoid checking them into [the main
Flutter repository](https://github.com/flutter/flutter), where they would
permanently increase the checkout size over time if altered.
