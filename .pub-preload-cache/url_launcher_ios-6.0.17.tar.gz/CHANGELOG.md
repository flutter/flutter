## 6.0.17

* Suppresses warnings for pre-iOS-13 codepaths.

## 6.0.16

* Fixes library_private_types_in_public_api, sort_child_properties_last and use_key_in_widget_constructors
  lint warnings.

## 6.0.15

* Switches to an in-package method channel implementation.

## 6.0.14

* Updates code for new analysis options.
* Removes dependency on `meta`.

## 6.0.13

* Splits from `url_launcher` as a federated implementation.
