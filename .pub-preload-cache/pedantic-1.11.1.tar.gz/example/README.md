Please see
[Using the Lints](https://github.com/dart-lang/pedantic#using-the-lints).
