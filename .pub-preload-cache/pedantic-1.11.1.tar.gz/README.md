[![Pub](https://img.shields.io/pub/v/pedantic.svg)](https://pub.dev/packages/pedantic)

This package is deprecated.

Before it was deprecated, it was the way to get analysis options
matching those used internally at Google. This was useful because
it was a good starting point for which lints to enable.

Instead, please see [package:lints](https://pub.dev/packages/lints) which
is the lint recommendation from the Dart team, or
[package:flutter_lints](https://pub.dev/packages/flutter_lints) which
extends that for Flutter. These are better than the Google lint set
because they take into account the needs of all Dart users, not just
Google engineers.

To migrate away from `package:pedantic` please see the instructions
[here](https://github.com/dart-lang/lints#migrating-from-packagepedantic).
