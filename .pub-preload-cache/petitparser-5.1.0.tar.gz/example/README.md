PetitParser Examples
====================

For more complicated examples see the official [example repository](https://github.com/petitparser/dart-petitparser-examples) or the [demo page](https://petitparser.github.io/).
 
This directory contains the command-line calculator that is described in the introductory tutorial:
 
    dart petitparser/example/calc.dart "1 + 2 * 3"
