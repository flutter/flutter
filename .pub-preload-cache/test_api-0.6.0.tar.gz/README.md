[![pub package](https://img.shields.io/pub/v/test_api.svg)](https://pub.dev/packages/test_api)
[![package publisher](https://img.shields.io/pub/publisher/test_api.svg)](https://pub.dev/packages/test_api/publisher)

A minimal package for writing tests. At this time this package is not intended
to be publicly used as the API will take time to stabilize.

If you're interested in testing Dart code, you likely want to use
[package:test](https://pub.dev/packages/test).
