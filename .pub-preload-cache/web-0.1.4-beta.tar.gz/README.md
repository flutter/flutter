[![Dart CI](https://github.com/dart-lang/web/actions/workflows/test-package.yml/badge.svg)](https://github.com/dart-lang/web/actions/workflows/test-package.yml)

Lightweight DOM and JS bindings built around JS static interop.

<!-- START updated by /tool/update_bindings.dart. Do not modify by hand -->
Based on [`@webref/idl 3.33.3`](https://www.npmjs.com/package/@webref/idl/v/3.33.3)
<!-- END updated by /tool/update_bindings.dart. Do not modify by hand -->

NOTE: This package is highly experimental.
