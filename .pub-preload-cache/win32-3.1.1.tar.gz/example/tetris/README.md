This example is a Dart port of an open source Win32 Tetris game by
Chang-Hung Liang.

The original C version can be found here:
<https://github.com/eliangcs/tetris-win32>

Original is licensed under the following terms:

> Anyone is free to copy, modify, publish, use, compile, sell, or
> distribute this software, either in source code form or as a compiled
> binary, for any purpose, commercial or non-commercial, and by any
> means.

Used with thanks.
