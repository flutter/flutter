import '../../com/iinspectable.dart';

class User extends IInspectable {
  User.fromRawPointer(super.ptr);
}
