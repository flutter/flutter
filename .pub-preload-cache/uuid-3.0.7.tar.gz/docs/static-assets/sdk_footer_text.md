&bull; [cc license](http://creativecommons.org/licenses/by-sa/4.0/)
