// Copyright (c) 2021, the Dart project authors.  Please see the AUTHORS file
// for details. All rights reserved. Use of this source code is governed by a
// BSD-style license that can be found in the LICENSE file.

@Deprecated('Moved to src/expect/async_matcher.dart')
library test_api.src.frontend.async_matcher;

// Temporary re-export to reduce churn in flutter_test.
export '../expect/async_matcher.dart';
