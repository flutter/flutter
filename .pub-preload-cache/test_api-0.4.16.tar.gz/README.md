A minimal package for writing tests. At this time this package is not intended
to be publicly used as the API will take time to stabilize.

If you're interested in testing Dart code, you likely want to use
[package:test](https://pub.dev/packages/test).
