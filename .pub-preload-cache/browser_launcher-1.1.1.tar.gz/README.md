[![Dart](https://github.com/dart-lang/browser_launcher/workflows/Dart/badge.svg)](https://github.com/dart-lang/browser_launcher/actions?query=workflow%3ADart+branch%3Amaster)
[![pub package](https://img.shields.io/pub/v/browser_launcher.svg)](https://pub.dev/packages/browser_launcher)
[![package publisher](https://img.shields.io/pub/publisher/browser_launcher.svg)](https://pub.dev/packages/browser_launcher/publisher)

Provides a standardized way to launch web browsers.

Currently, Chrome is the only supported browser; support for other browsers may
be added in the future.
