A Chrome extension for enabling Dart application debugging over an SSE
connection with package:dwds.

## Installation

The extension is available on the
[Chrome Web Store](https://chrome.google.com/webstore/detail/dart-debug-extension/eljbmlghnomdjgdjmbdekegdkbabckhm).

## Usage

The extension requires disabling 'Throttle expensive background timers' in
`chrome://flags` to ensure proper performance.
